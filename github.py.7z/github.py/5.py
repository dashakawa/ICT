a = int(input())
b = int(input())
c = 0.10* a + 0.25 * b
print(f'{c:.2f}',"$")