width = float(input())
length = float(input())
area = width * length / 43560
print("Area " + str(area) + " acre")