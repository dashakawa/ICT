r = int(input())
from math import pi
print(f'Area of circle: {pi*r*r}, volume of sphere: {(4*pi*r**3)/3}')