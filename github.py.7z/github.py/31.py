s = input()
sum = 0
for i in s:
    sum += int(i)
print(sum)