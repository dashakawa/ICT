mass = int(input())
delta_t = int(input())
print('Amount of energy:', mass*4.186*delta_t)
print('Price:', mass*4.186*delta_t*8.9/3600000)