f = int(input())
print(f'In inches: {f*12}, in yards: {f/3}, in miles: {f/5280}')