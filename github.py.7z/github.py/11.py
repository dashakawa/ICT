print("MPG:")
mpg = int(input())
kanFEN = float((mpg * 3.75541) / 1.60934)
print(f'{kanFEN/100:.2f}',"L/100km")