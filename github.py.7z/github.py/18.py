pi = 3.14
r = float(input())
h = float(input())
V = pi * h * (r**2)
print(f'{V:.1f}',"m^3")