feet = int(input())
inches = int(input())
print('In centimeters:', (feet*12 + inches)*2.54)