n = int(input())
print(n+273.15,"kelvins")
print((n*1.8)+32,"fahrenheit")