a = int(input())
print('regular price-', (a * 3.49), '$')
print('discount-', (a * 3.49 * 0.6), '$')
print('price-', ((a * 3.49) - (a * 3.49 * 0.6)))
