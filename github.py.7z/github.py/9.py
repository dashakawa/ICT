balance = int(input())
print("Balance after 1 year:",f'{balance*1.04:.2f}')
print("Balance after 2 year:",f'{balance*(1.04**2):.2f}')
print("Balance after 3 year:",f'{balance*(1.04**3):.2f}')