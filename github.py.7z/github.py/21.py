b = int(input())
h = int(input())
area = float((b*h)/2)
print(f'{area:.2f}',"m^2")