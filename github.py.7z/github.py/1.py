print ("Alimbayeva Dariga")
print ("Mira street 12")
print ("KZ, Zhezkazgan")