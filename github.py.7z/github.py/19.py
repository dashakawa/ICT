Vi = 0
a = 9.8
d = float(input())
vf = 2 * Vi + 2 * a * d
print(vf,"m/sec")