h = float(input())
w = float(input())
BMI = float(w/(h**2))
print(f'{BMI:.3f}',"kg/m^2")