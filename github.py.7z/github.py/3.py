width = float(input())
length = float(input())
area = width * length
print("Area room " + str(area) + " m^2")