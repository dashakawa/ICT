a = int(input())
print('pounds per square inch ', a * 1000 / 6894,75729)

print('millimeters of mercury ', a / 133, 132 * 1000)

print('atmosphere ', (a * 1000 / 101325))